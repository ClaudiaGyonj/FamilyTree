package com.example.familybuilder_ia;

import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;


public class FamilyInfoScene extends Scene {

    private static final ImageView imageView = new ImageView();
    private static final Button fileButton = new Button("Choose profile img");
    private static final Label errorMessage = new Label("");
    private static final ArrayList<TextField> textFields = new ArrayList<>();
    private static final ChoiceBox<String> parentChoice = new ChoiceBox<>();
    private static final FileChooser fileChooser = new FileChooser();
    private static String profileImgPath = null;
    private static final File defaultFile = new File("C:\\Users\\vergi\\IdeaProjects\\FamilyBuilder_IA\\target\\classes\\com\\example\\familybuilder_ia\\" +
            "icon.png");


    public FamilyInfoScene(Parent parent, double v, double v1) {
        super(parent, v, v1);
    }

    public static BorderPane buildLayout(GridPane grid, Button saveButton, Button cancelButton, TreeNode selectedNode){
        if(!textFields.isEmpty()){ //clears the text fields every time a new family info scene is made
            textFields.clear();
        }
        grid = new GridPane();
        grid.setPadding(new Insets(8, 10, 10, 45));
        grid.setVgap(8);
        grid.setHgap(10);
        grid.setBackground(new Background(new BackgroundFill(Color.rgb(209, 226, 245), null, null)));

        Label[] textLabels = makeLabels();

        //adds labels and text fields to grid layout
        for(int index = 0; index < 5; index++){
            Label textLabel = textLabels[index];
            GridPane.setConstraints(textLabel, 0, index + 1);
            grid.getChildren().add(textLabel);
            if(index == 1){ //skips the parent label to add a choice box there later on
                continue;
            }
            TextField textField = new TextField();
            textFields.add(textField);
            GridPane.setConstraints(textField, 1, index + 1);
            grid.getChildren().add(textField);

        }

        //populates the text fields with the selected TreeNode if it exists
        if(selectedNode != null){
            textFields.get(0).setText(selectedNode.getData().getName());
            textFields.get(1).setText(selectedNode.getData().getBirthday());
            textFields.get(2).setText(selectedNode.getData().getAge());
            textFields.get(3).setText(selectedNode.getData().getSpouseName());
        }


        // makes parent drop-down list
        parentChoice.setMinWidth(150);
        GridPane.setConstraints(parentChoice, 1, 2);
        if(selectedNode != null){ //if a TreeItem was selected, the parent choice box is set to the name of its parent
            parentChoice.getItems().clear();
            parentChoice.setValue(selectedNode.getData().getParentName());
        } else if(HomePage.isTreeNull){ //if no family members were added yet, the parent choice box is set to "unknown"
            parentChoice.setValue("Unknown");
        } else { //if a new family member is being added, all current family members are added to the choice box list
            parentChoice.setValue(null);
            parentChoice.getItems().clear();
            ArrayList<String> obtainMembers = new ArrayList<>();
            ArrayList<String> currentMembers = FamilyTree.getListOfMembers(FamilyTree.overallRoot, obtainMembers);
            for (String member : currentMembers) {
                parentChoice.getItems().add(member);
            }
        }

        //sets up choose profile image button
        fileButton.setOnAction(FamilyInfoScene::handleOpenImgFile);
        fileButton.setStyle(
                "-fx-background-color: #FFF4B9;" +
                "-fx-font-family: Georgia;"
        );
        GridPane.setConstraints(fileButton, 0, 6);


        //sets up save and cancel buttons
        HBox buttonBox = new HBox();
        buttonBox.getChildren().add(saveButton);
        buttonBox.getChildren().add(cancelButton);
        buttonBox.setSpacing(20);
        buttonBox.setAlignment(Pos.CENTER_RIGHT);
        GridPane.setConstraints(buttonBox, 1, 7);

        grid.getChildren().addAll(fileButton, buttonBox, parentChoice);



        //if a TreeItem was selected, the image inputted before is reloaded
        if(selectedNode != null && selectedNode.getData().getProfileImagePath() != null){
            profileImgPath = selectedNode.getData().getProfileImagePath();
            File selectedFile = new File(profileImgPath);
            setImageView(imageView, selectedFile);
        } else{ //otherwise, the default profile image is used
            profileImgPath = defaultFile.getPath();
            setImageView(imageView, defaultFile);
        }
        imageView.setFitHeight(150);
        imageView.setFitWidth(150);
        imageView.setPreserveRatio(true);



        //positioning and styling
        BorderPane layout = new BorderPane();
        errorMessage.setTextFill(Color.RED);
        VBox errorAndImg = new VBox();
        errorAndImg.setSpacing(20);
        errorAndImg.setAlignment(Pos.CENTER);
        errorAndImg.setBackground(new Background(new BackgroundFill(Color.rgb(209, 226, 245), null, null)));
        errorAndImg.getChildren().addAll(imageView, errorMessage);
        VBox.setMargin(imageView, new Insets(25, 0, 0, 0));

        layout.setTop(errorAndImg);
        layout.setCenter(grid);

        return layout;


    }

    private static Label[] makeLabels(){
        /*
        this method creates all the labels that will go in the family info scene, inputs them into a list,
        and returns the list
         */
        Label[] textLabels = new Label[5];
        textLabels[0] = new Label("Name: ");
        textLabels[1] = new Label("Parent Name: ");
        textLabels[2] = new Label("Birthday: " +
                "(MM-DD-YYYY)");
        textLabels[3] = new Label("Age: ");
        textLabels[4] = new Label("Spouse Name: ");

        for(Label label : textLabels){
            label.setFont(new Font("Georgia", 12));
        }

        return textLabels;
    }

    private static void setImageView(ImageView imageView, File profileImg) {
        //this method takes an image file and uploads it to the screen with an image view
        imageView.setImage(new Image(profileImg.toURI().toString()));
    }


    private static void handleOpenImgFile(ActionEvent event){
        //allows user to choose file and upload to screen
        HomePage hmPage = new HomePage();
        configureFileChooser(fileChooser);
        File chosenFile = fileChooser.showOpenDialog(hmPage.window);
        profileImgPath = chosenFile.getPath();
        if(chosenFile != null){
            setImageView(imageView, chosenFile);
        }

    }


    private static void configureFileChooser(FileChooser fileChooser) {
        //sets up file chooser and limits files to jpg
        fileChooser.setTitle("View Pictures");
        fileChooser.setInitialDirectory(new File(System.getProperty("user.home")));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPG", "*.jpg"));

    }

    public static boolean validateUserInput(){
        //obtains data from text fields
        String nameText = textFields.get(0).getText();
        String birthdayText = textFields.get(1).getText();
        String ageText = textFields.get(2).getText();
        String spouseText = textFields.get(3).getText();
        String errorText = "";

        boolean areAllInputsCorrect = true;


        //verifies the name and spouse fields and adds each error to the overall error text
        Scanner nameScan = new Scanner(nameText);
        boolean isNameThere = nameScan.hasNext();

        Scanner spouseScan = new Scanner(spouseText);
        boolean isSpouseNameThere = spouseScan.hasNext();

        if(isNameThere && !isSpouseNameThere){
            if(!isOnlyLetters(nameText)){
                errorText += "Name must be in letters only.";
                areAllInputsCorrect = false;
            }
        } else if(isSpouseNameThere && isNameThere){
            if(!isOnlyLetters(nameText) && isOnlyLetters(spouseText)){
                errorText += "Name must be in letters only.";
                areAllInputsCorrect = false;
            } else if(!isOnlyLetters(spouseText) && isOnlyLetters(nameText)){
                errorText += "Spouse name must be in letters only.";
                areAllInputsCorrect = false;
            } else if(!isOnlyLetters(spouseText) && !isOnlyLetters(nameText)){
                errorText += "Name and spouse name must be in letters only.";
                areAllInputsCorrect = false;
            }
        } else if(isSpouseNameThere){
            if(!isOnlyLetters(spouseText)){
                errorText += "Name is a required field, and spouse name must be in letters only.";
            } else{
                errorText += "Name is a required field.";
            }
            areAllInputsCorrect = false;
        } else{
            errorText += "Name is a required field.";
            areAllInputsCorrect = false;
        }

        //verifies age field and adds any errors to overall error text
        Scanner ageCheck = new Scanner(ageText);
        if(ageCheck.hasNext()){
            try{
                int ageNum = Integer.parseInt(ageText);
                if(ageNum < 0){
                    errorText += "\nAge cannot be less than 0.";
                    areAllInputsCorrect = false;
                }
            } catch(NumberFormatException e){
                boolean ageCorrect = true;
                for(int i = 0; i < ageText.length(); i++){
                    char ch = ageText.charAt(i);
                    if(!Character.isDigit(ch)){
                        ageCorrect = false;
                        areAllInputsCorrect = false;
                    }
                }
                if(!ageCorrect){
                    errorText += "\nAge must be a number.";
                }
            }
        }

        //verifies birthday format and adds any errors to overall error text
        Scanner birthCheck = new Scanner(birthdayText);
        if(birthCheck.hasNext()){
            boolean isBirthdayCorrect = isMMDDYYYYFormat(birthdayText);
            if(!isBirthdayCorrect){
                errorText += "\nBirthday is not in the correct format.";
                areAllInputsCorrect = false;
            }
        }

       //verifies if a parent is chosen and adds any error to overall error text
        if(parentChoice.getItems().size() > 0){
            if(parentChoice.getValue() == null){
                errorText += "\nA parent must be chosen.";
                areAllInputsCorrect = false;
            }

        }

        errorMessage.setText(errorText);
        return areAllInputsCorrect;

    }


    private static boolean isMMDDYYYYFormat(String input) {
        //this method uses the SimpleDateFormat class to check if a String birthday is in the correct format
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(input.trim());
        } catch (ParseException e) {
            return false;
        }
        return true;
    }

    private static boolean isOnlyLetters(String input) {
        //checks if a String only contains letters
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (!String.valueOf(ch).equals(" ") && !Character.isLetter(ch)) {
                return false;
            }
        }
        return true;
    }

    public ArrayList<TextField> getTextFields(){
        return textFields;
    }

    public ChoiceBox<String> getChoiceBox(){
        return parentChoice;
    }

    public String getProfileImgPath(){
        return profileImgPath;
    }

}
