package com.example.familybuilder_ia;

import java.io.Serializable;
import java.util.ArrayList;

public class TreeNode implements Serializable {

    private FamilyMember data;
    public ArrayList<TreeNode> children = new ArrayList<>();



    public TreeNode(FamilyMember data, ArrayList<TreeNode> children){
        this.data = data;
        this.children = children;
    }

    public TreeNode(FamilyMember data){
        this.data = data;
    }

    public FamilyMember getData() {
        return data;
    }

    public void setData(FamilyMember data) {
        this.data = data;
    }

    public ArrayList<TreeNode> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<TreeNode> children) {
        this.children = children;
    }
}
