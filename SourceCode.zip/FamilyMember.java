package com.example.familybuilder_ia;

import java.io.Serializable;

public class FamilyMember implements Serializable {

    private String name;
    private String spouseName;
    private String age;
    private String birthday;
    private String parentName;
    private String profileImagePath;


    public FamilyMember(String name, String spouseName, String age, String birthday, String parentName, String profileImgPath){
        this.name = name;
        this.spouseName = spouseName;
        this.age = age;
        this.birthday = birthday;
        this.parentName = parentName;
        this.profileImagePath = profileImgPath;
    }

    //Getters and setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpouseName() {
        return spouseName;
    }

    public void setSpouseName(String spouseName) {
        this.spouseName = spouseName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getProfileImagePath() {
        return profileImagePath;
    }

    public void setProfileImagePath(String profileImage) {
        this.profileImagePath = profileImagePath;
    }
}
