package com.example.familybuilder_ia;

import java.util.ArrayList;
import java.util.List;

public class FamilyTree {

    public static TreeNode overallRoot;


    public FamilyTree(TreeNode overallRoot){
        FamilyTree.overallRoot = overallRoot;
    }

    public void addChild(TreeNode parent, TreeNode child) {
        //adds a child to its parent
        parent.children.add(child);
    }

    public void removeChild(TreeNode parent, TreeNode childToRemove) {
        //this method was added for future extensibility
        List<TreeNode> children = parent.getChildren();
        if (children.isEmpty()) {
            return;
        } else {
            children.remove(childToRemove);

        }
    }

    public TreeNode findNode(String name) {
        return findNode(overallRoot, name);
    }

    private TreeNode findNode(TreeNode root, String name) {
        //recursively searches the family tree starting at the root to find a TreeNode using its name
        if (root == null || name == null) {
            return null;
        }
        if (root.getData().getName().equals(name)) {
            return root;
        } else {
            for (TreeNode child : root.getChildren()) {
                TreeNode foundNode = findNode(child, name);
                if (foundNode != null) {
                    return foundNode;
                }
            }
        }
        return null;
    }

    public static void preOrderTraversal(TreeNode root, ArrayList<TreeNode> list) {
        //adds all TreeNodes in the FamilyTree to a TreeNode list in pre-order
        if (root == null) {
            return;
        }
        list.add(root);
        for (TreeNode child : root.getChildren()) {
            preOrderTraversal(child, list);
        }
    }


    public static ArrayList<String> getListOfMembers(TreeNode root, ArrayList<String> memberList ){
        //adds all TreeNode names in the FamilyTree to a String list in pre-order
        if(root == null){
            return memberList;
        }
        memberList.add(root.getData().getName());
        for(TreeNode child : root.getChildren()){
            getListOfMembers(child, memberList);
        }
        return memberList;
    }

    public TreeNode getOverallRoot(){
        return overallRoot;
    }

    public void setOverallRoot(TreeNode root){
        this.overallRoot = root;
    }





}
