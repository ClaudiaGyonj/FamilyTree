package com.example.familybuilder_ia;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.Node;
import java.io.*;
import java.util.ArrayList;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

public class HomePage extends Application {

    //homepage variables
    private FamilyTree familyTree;
    private TreeView<String> treeStructure;
    private TreeItem<String> rootItem = new TreeItem<>();
    public Stage window = new Stage();
    private final Button plusButton = new Button();
    private BorderPane layout = new BorderPane();
    private Scene mainScene;
    public final int xDimension = 400;
    public final int yDimension = 500;
    private final Button saveButton = new Button("Save");
    private final Button cancelButton = new Button("Cancel");
    public static boolean isTreeNull = true;
    private TreeItem<String> selectedItem = new TreeItem<>();
    private final String buttonStyling =  "-fx-background-color: #FFF4B9;" +
            "-fx-font-family: Georgia;";


    public static void main(String[] args) {
        launch();
    }


    @Override
    public void start(Stage primaryStage){

        //sets up window, adds close action listener
        window = primaryStage;
        window.setTitle("Family Tree Builder");
        window.setOnCloseRequest(e -> {
            try {
                closeApp();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        //sets up plus button and save and cancel buttons for a new family member scene
        saveButton.setStyle(buttonStyling);
        cancelButton.setStyle(buttonStyling);
        plusButton.setText("+");
        plusButton.setFont(new Font("Georgia", 20));
        plusButton.setOnAction(this::handleAddMember);
        plusButton.setStyle(
                "-fx-background-radius: 5em; " +
                        "-fx-min-width: 45px; " +
                        "-fx-min-height: 45px; " +
                        "-fx-max-width: 45px; " +
                        "-fx-max-height: 45px;" +
                        "-fx-background-color: #FFAB61;"

        );


        //sets up tree view and adds listener for when user clicks on family members
        rootItem.setExpanded(true);
        treeStructure = new TreeView<>(rootItem);
        styleTreeView(treeStructure);
        EventHandler<MouseEvent> mouseEventHandle = this::handleMemberClicked;
        treeStructure.addEventHandler(MouseEvent.MOUSE_CLICKED, mouseEventHandle);


        //plus button positioning
        StackPane buttonPos = new StackPane();
        buttonPos.getChildren().add(plusButton);
        buttonPos.setAlignment(Pos.CENTER_RIGHT);
        StackPane.setMargin(plusButton, new Insets(0, 20, 10, 0));


        //home page title set up
        Label title = new Label("My Family");
        title.setFont(new Font("Georgia", 25));
        title.setStyle(
                "-fx-text-fill:#0b4355;"
        );
        StackPane titlePos = new StackPane();
        titlePos.setPadding(new Insets(10, 0, 0, 0));
        titlePos.getChildren().add(title);
        titlePos.setAlignment(Pos.CENTER);


        //main layout set up: tree view in center, title at top, plus button at bottom
        layout = new BorderPane();
        layout.setTop(titlePos);
        layout.setCenter(treeStructure);
        layout.setBottom(buttonPos);
        BorderPane.setMargin(treeStructure, new Insets(5, 15, 5, 15));

        //sets up main scene
        mainScene = new Scene(layout, xDimension, yDimension);
        window.setScene(mainScene);
        window.show();
        buttonPos.requestFocus();

        //loads data to page if it exists
        ArrayList<TreeNode> nodePreOrderList = getSavedInfo();
        openApp(nodePreOrderList);


    }

    private void styleTreeView(TreeView<String> treeStructure){
        /*
        this method overrides the updateItem method in the Cell class, which is inherited
        by the TreeCell class, to customize the styling of each TreeItem in the TreeView.
         */
        treeStructure.setCellFactory(tv -> new TreeCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setBackground(null);
                } else {
                    setText(item);
                    setFont(new Font("Georgia", 12));
                    setBackground(new Background(new BackgroundFill(Color.rgb(209, 226, 245), null, null)));
                }
            }

        });
    }

    private void handleMemberClicked(MouseEvent event) {
        Node node = event.getPickResult().getIntersectedNode();
        if (node instanceof Text || (node instanceof TreeCell && ((TreeCell) node).getText() != null) && familyTree != null) {
            //checks if a TreeItem was clicked, not another part of the TreeView
            if (event.getButton() == MouseButton.PRIMARY) { //ensures the method doesn't execute because of a right click
                //obtains selected TreeItem and corresponding TreeNode
                selectedItem = treeStructure.getSelectionModel().getSelectedItem();
                String name = selectedItem.getValue();
                TreeNode selectedTreeNode = familyTree.findNode(name);

                //makes populated info scene and displays it
                GridPane newGrid = new GridPane();
                Button newSaveButton = new Button("Save");
                newSaveButton.setStyle(buttonStyling); //buttonStyling is a constant String that contains styling information in CSS
                Button newCancelButton = new Button("Cancel");
                newCancelButton.setStyle(buttonStyling);
                newCancelButton.setOnAction(e -> window.setScene(mainScene));
                FamilyInfoScene updateScene = new FamilyInfoScene(FamilyInfoScene.buildLayout(newGrid, newSaveButton, newCancelButton, selectedTreeNode), xDimension, yDimension);
                newSaveButton.setOnAction(e -> onUpdate(updateScene, selectedTreeNode, selectedItem));
                window.setScene(updateScene);
            }

        }
    }

    private void handleAddMember(ActionEvent actionEvent) {
        //makes a new family info scene and displays it
        GridPane grid = new GridPane();
        cancelButton.setOnAction(e -> window.setScene(mainScene));
        FamilyInfoScene familyInfoScene = new FamilyInfoScene(FamilyInfoScene.buildLayout(grid, saveButton, cancelButton, null), xDimension, yDimension);
        saveButton.setOnAction(e -> onSave(familyInfoScene));
        window.setScene(familyInfoScene);

    }


    private void onUpdate(FamilyInfoScene updateScene, TreeNode selectedTreeNode, TreeItem<String> selectedItem) {
        if (!FamilyInfoScene.validateUserInput()){ //if the user made an error, the method cannot continue
            return;
        }

        FamilyMember memberData = makeFamilyMember(updateScene); //makes a new FamilyMember data object with the scene's fields
        selectedTreeNode.setData(memberData); //resets the selected TreeNode's data
        selectedItem.setValue(memberData.getName()); //resets the name of the selected TreeItem
        for(TreeNode child : selectedTreeNode.getChildren()){ //resets the parent name in the choice boxes of each of the selectedTreeItem's children
            child.getData().setParentName(memberData.getName());
        }
        window.setScene(mainScene); //returns to the home page
        plusButton.requestFocus();


    }


    public void onSave(FamilyInfoScene familyInfoScene) {
        if (!FamilyInfoScene.validateUserInput()) { //if the user made an error, the method cannot continue
            return;
        }
        //makes a new FamilyMember data object with the scene's fields
        FamilyMember memberData = makeFamilyMember(familyInfoScene);
        String name = memberData.getName();
        String parentName = memberData.getParentName();

        //adds root or child to tree data structure and TreeView
        if (familyTree == null) {
            TreeNode rootNode = new TreeNode(memberData);
            familyTree = new FamilyTree(rootNode);
            familyTree.setOverallRoot(rootNode);
            isTreeNull = false;
            treeStructure.setShowRoot(true);
            rootItem.setValue(name);
        } else {
            isTreeNull = false;
            TreeNode child = new TreeNode(memberData);
            TreeNode parent = familyTree.findNode(parentName);
            familyTree.addChild(parent, child);
            TreeItem<String> parentItem = findTreeItem(rootItem, parentName);
            makeBranch(name, parentItem);
        }
        window.setScene(mainScene); //returns to home page
        plusButton.requestFocus();
    }

    private FamilyMember makeFamilyMember(FamilyInfoScene infoScene) {
        //obtains and returns family member data from data fields in the family info scene
        ArrayList<TextField> textFields = infoScene.getTextFields();
        String name = textFields.get(0).getText();
        String parentName = infoScene.getChoiceBox().getValue();
        String birthday = textFields.get(1).getText();
        String age = textFields.get(2).getText();
        String spouse = textFields.get(3).getText();
        String profileImgPath = infoScene.getProfileImgPath();

        FamilyMember memberData = new FamilyMember(name, spouse, age, birthday, parentName, profileImgPath);
        return memberData;
    }


    private void makeBranch(String name, TreeItem<String> parent) {
        //creates the child TreeItem and adds it to its parent
        TreeItem<String> child = new TreeItem<>(name);
        child.setExpanded(true);
        parent.getChildren().add(child);
    }

    private void closeApp() throws IOException {
        if(familyTree == null){ //if no family members were added, this method is irrelevant
            return;
        }

        /*
        if TreeNodes were added from the family members made, then those TreeNodes will be arranged in a pre-order
        list and saved to a text file upon closing the app
         */
        FileOutputStream fileOut = new FileOutputStream("storage_file.txt");
        ObjectOutputStream outputStream = new ObjectOutputStream(fileOut);
        ArrayList<TreeNode> nodePreOrderList = new ArrayList<>();
        FamilyTree.preOrderTraversal(familyTree.getOverallRoot(), nodePreOrderList);
        for (TreeNode member : nodePreOrderList) {
            outputStream.writeObject(member);
        }
        outputStream.close();
        fileOut.close();

    }

    private ArrayList<TreeNode> getSavedInfo() {
        //returns the TreeNode pre-order list from the text file if it exists
        try {
            ArrayList<TreeNode> nodePreOrderList = new ArrayList<>();
            FileInputStream fileIn = new FileInputStream("storage_file.txt");
            ObjectInputStream inputStream = new ObjectInputStream(fileIn);
            while (fileIn.available() > 0) {
                nodePreOrderList.add((TreeNode) inputStream.readObject());
            }

            return nodePreOrderList;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    private void openApp(ArrayList<TreeNode> nodePreOrderList) {
        if (nodePreOrderList == null) { //if no data was added previously, this method is irrelevant
            return;
        }
        TreeNode rootNode = nodePreOrderList.get(0); //the root is always the first item in pre-order
        familyTree = new FamilyTree(rootNode);
        isTreeNull = false;
        rootItem.setValue(rootNode.getData().getName());

        for (int i = 1; i < nodePreOrderList.size(); i++) {
            /*
            For every TreeNode in the pre-order list except the root, the algorithm makes a TreeItem using the TreeNode's
            name. It then finds the parent TreeItem using the parent name, assuming the parent is not the root,
            and adds the TreeItem to its parent's children.
             */
            TreeNode child = nodePreOrderList.get(i);
            String childName = child.getData().getName();
            String parentName = child.getData().getParentName();
            TreeItem<String> parent;
            TreeItem<String> childItem = new TreeItem<>(childName);
            childItem.setExpanded(true);

            if (parentName.equals(rootItem.getValue())) {
                rootItem.getChildren().add(childItem);
            } else {
                parent = findTreeItem(rootItem, parentName);
                parent.getChildren().add(childItem);

            }
        }
    }


    private static TreeItem<String> findTreeItem(TreeItem<String> root, String value) {
        //this method recursively searches the tree view using the root item for a TreeItem with a particular name
        if (root == null || value == null) {
            return null;
        }
        if (root.getValue().equals(value)) {
            return root;
        }
        for (TreeItem<String> child : root.getChildren()) {
            TreeItem<String> found = findTreeItem(child, value);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

}